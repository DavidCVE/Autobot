import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np

class FreeSpaceFollower(Node):
    def __init__(self):
        super().__init__('free_space_follower')
        self.bridge = CvBridge()
        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',  # Topic actualizat pentru Waffle Pi
            self.image_callback,
            10
        )

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)  # Topic pentru controlul robotului

    def image_callback(self, msg):
        self.get_logger().info("Imagine primită de la cameră.")
        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        resized_frame = cv2.resize(frame, (640, 480))
        blur = cv2.blur(resized_frame, (3, 3))
        edge = cv2.Canny(blur, 100, 200)  # Ajustat pragurile pentru detecția marginilor

        # Detectăm culoarea roșie
        red_mask = self.detect_red(resized_frame)
        cv2.imshow("Red Mask", red_mask)  # Afișăm masca roșie pentru debugging

        # Verificăm dacă există semnul STOP
        stop_detected = self.detect_stop_sign_shape(red_mask, resized_frame)
        if stop_detected:
            self.get_logger().info("Semn STOP detectat! Robotul se oprește.")
            twist = Twist()
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.cmd_pub.publish(twist)
            cv2.imshow("Camera Feed", resized_frame)
            cv2.waitKey(1)
            return  # Nu mai procesăm alte comenzi

        # Continuăm logica pentru urmărirea liniei dacă nu detectăm semnul STOP
        centroid_x, centroid_y, width, height, img_with_arrow = self.freespace(edge, resized_frame)

        if centroid_x is not None:
            error = centroid_x - width // 2
            twist = Twist()
            twist.linear.x = 0.2  # Viteză liniară constantă
            twist.angular.z = -error / 100  # Rotație bazată pe eroare
            self.cmd_pub.publish(twist)
            self.get_logger().info(f"Robotul urmărește linia. Eroare: {error}")
        else:
            twist = Twist()
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.cmd_pub.publish(twist)
            self.get_logger().info("Linie pierdută. Robotul s-a oprit.")

        cv2.imshow("Camera Feed", img_with_arrow)
        cv2.waitKey(1)

    def freespace(self, canny_frame, img):
        height, width = canny_frame.shape
        DreaptaLim = width // 2
        StangaLim = width // 2
        mask = np.zeros((height, width), dtype=np.uint8)
        contour = []

        for i in range(width // 2, width - 1):
            if canny_frame[height - 10, i]:
                DreaptaLim = i
                break
        for i in range(width // 2):
            if canny_frame[height - 10, width // 2 - i]:
                StangaLim = width // 2 - i
                break
        if StangaLim == width // 2:
            StangaLim = 1
        if DreaptaLim == width // 2:
            DreaptaLim = width
        contour.append((StangaLim, height - 10))
        cv2.circle(img, (StangaLim, height - 10), 5, (255), -1)
        cv2.circle(img, (DreaptaLim, height - 10), 5, (255), -1)

        for j in range(StangaLim, DreaptaLim - 1, 10):
            for i in range(height - 10, 9, -1):
                if canny_frame[i, j]:
                    cv2.line(img, (j, height - 10), (j, i), (255), 2)
                    contour.append((j, i))
                    break
                if i == 10:
                    contour.append((j, i))
                    cv2.line(img, (j, height - 10), (j, i), (255), 2)
        contour.append((DreaptaLim, height - 10))
        contours = [np.array(contour)]
        cv2.drawContours(mask, contours, 0, (255), cv2.FILLED)

        M = cv2.moments(contours[0])
        if M["m00"] != 0:
            centroid_x = int(M["m10"] / M["m00"])
            centroid_y = int(M["m01"] / M["m00"])
            cv2.arrowedLine(img, (width // 2, height - 10), (centroid_x, centroid_y), (60, 90, 255), 4)
            return centroid_x, centroid_y, width, height, img
        else:
            return None, None, width, height, img

    def detect_red(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # Interval pentru culoarea roșie
        lower_red1 = np.array([0, 50, 50])     # Prag ajustat pentru roșu deschis
        upper_red1 = np.array([10, 255, 255])

        lower_red2 = np.array([170, 50, 50])   # Prag ajustat pentru roșu închis
        upper_red2 = np.array([180, 255, 255])

        mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(hsv, lower_red2, upper_red2)

        return mask1 + mask2

    def detect_stop_sign_shape(self, mask, frame):
        contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            approx = cv2.approxPolyDP(contour, 0.01 * cv2.arcLength(contour, True), True)
            if len(approx) == 8:  # Forma octogonală
                x, y, w, h = cv2.boundingRect(approx)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)  # Evidențiază semnul STOP
                self.get_logger().info("Semn STOP detectat în imagine!")
                return True
        return False


def main(args=None):
    rclpy.init(args=args)
    node = FreeSpaceFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
