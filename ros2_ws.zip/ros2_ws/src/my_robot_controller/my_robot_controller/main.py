import cv2
import numpy as np
# Open the default camera
cam = cv2.VideoCapture(0)
 
cam.set(cv2.CAP_PROP_FRAME_WIDTH, 480)
cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 640)
 
def freespace(canny_frame, img):
        height, width = canny_frame.shape
        print(canny_frame.shape)
        DreaptaLim = width // 2
        StangaLim = width // 2
 
        mask = np.zeros((height, width), dtype=np.uint8)
        contour = []
 
        # Set right limit
        for i in range(width // 2, width-1):
            if canny_frame[height - 10, i]:
                DreaptaLim = i
                break
 
        # Set left limit
        for i in range(width // 2):
            if canny_frame[height - 10, width // 2 - i]:
                StangaLim = width // 2 - i
                break
 
        # Adjust limits
        if StangaLim == width // 2:
            StangaLim = 1
        if DreaptaLim == width // 2:
            DreaptaLim = width
        contour.append((StangaLim, height - 10))
        cv2.circle(img,( StangaLim,height-10),5,(255),-1)
        cv2.circle(img,( DreaptaLim, height-10),5,(255),-1)
 
        for j in range(StangaLim, DreaptaLim - 1, 10):
            for i in range(height - 10, 9, -1):
                if canny_frame[i, j]:
                    cv2.line(img, (j, height - 10), (j, i), (255), 2)
                    contour.append((j, i))
                    break
                if i == 10:
                    contour.append((j, i))
                    cv2.line(img, (j, height - 10), (j, i), (255), 2)
        contour.append((DreaptaLim, height - 10))
        contours = [np.array(contour)]
        cv2.drawContours(mask, contours, 0, (255), cv2.FILLED)
        cv2.imshow("mask", mask)
        M = cv2.moments(contours[0])
        if M["m00"] != 0:
            centroid_x = int(M["m10"] / M["m00"])
            centroid_y = int(M["m01"] / M["m00"])
        else:
            centroid_x, centroid_y = 0, 0
 
        cv2.arrowedLine(img,(width//2, height-10),(centroid_x,centroid_y),(60,90,255),4)
while True:
    ret, frame = cam.read()
 
    resized_frame = cv2.resize(frame,(640,480))
    # Write the frame to the output file
    # out.write(frame)
    blur = cv2.blur(resized_frame, (3,3))
    edge = cv2.Canny(blur, 160,180)
    freespace(edge,resized_frame)
    # Display the captured frame
    cv2.imshow('Camera', resized_frame)
    cv2.imshow('Edge',edge)
    cv2.imshow('Blur', blur)
    # Press 'q' to exit the loop
    if cv2.waitKey(20) == ord('q'):
        break
 
# Release the capture and writer objects
cam.release()
# out.release()
cv2.destroyAllWindows()
 
 