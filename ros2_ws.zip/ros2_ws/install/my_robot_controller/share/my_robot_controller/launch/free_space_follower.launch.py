from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='my_robot_controller',
            executable='free_space_follower',
            name='free_space_follower',
            output='screen',
        ),
    ])
